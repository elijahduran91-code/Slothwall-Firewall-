package com.slothwall.firewall;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.*;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 77;
    private final Set<String> blocked = new HashSet<>();
    private LinearLayout appList;
    private TextView status;
    private Switch lockdown;
    private Switch autostart;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        blocked.addAll(RuleStore.blocked(this));
        buildUi();
        requestNotifications();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        root.setBackgroundColor(Color.rgb(13,17,23));
        scroll.addView(root);

        TextView title = text("🦥  SLOTHWALL FIREWALL", 25, Color.rgb(240,246,252));
        title.setTypeface(null, 1); root.addView(title);
        TextView sub = text("Private, no-root app firewall", 14, Color.rgb(139,148,158));
        sub.setPadding(0,0,0,dp(14)); root.addView(sub);

        status = text("Firewall ready", 16, Color.rgb(63,185,80)); root.addView(status);

        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button start = button("START FIREWALL"); start.setOnClickListener(v -> requestVpnAndStart());
        Button stop = button("STOP"); stop.setOnClickListener(v -> stopFirewall());
        buttons.addView(start, new LinearLayout.LayoutParams(0, dp(52), 1));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(10), 1); buttons.addView(new Space(this), sp);
        buttons.addView(stop, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(buttons);

        lockdown = makeSwitch("LOCKDOWN — block all app internet", RuleStore.lockdown(this));
        lockdown.setOnCheckedChangeListener((b,v) -> RuleStore.setLockdown(this,v)); root.addView(lockdown);
        autostart = makeSwitch("Start protection after reboot", RuleStore.autostart(this));
        autostart.setOnCheckedChangeListener((b,v) -> RuleStore.setAutostart(this,v)); root.addView(autostart);

        TextView heading = text("BLOCKED APPS", 17, Color.WHITE); heading.setPadding(0,dp(18),0,dp(8)); heading.setTypeface(null,1); root.addView(heading);
        TextView hint = text("Check an app to block its internet access. Changes apply the next time the firewall starts.", 13, Color.rgb(139,148,158)); root.addView(hint);

        appList = new LinearLayout(this); appList.setOrientation(LinearLayout.VERTICAL); root.addView(appList);
        loadApps();

        Button logs = button("VIEW BLOCKED CONNECTION LOG"); logs.setOnClickListener(v -> showLogs()); root.addView(logs);
        Button vpnSettings = button("OPEN ANDROID VPN SETTINGS"); vpnSettings.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_VPN_SETTINGS)); } catch (Exception ignored) {}
        }); root.addView(vpnSettings);

        TextView privacy = text("Privacy: Slothwall stores blocked-connection logs only on this device. It does not decrypt HTTPS traffic and does not upload logs.", 12, Color.rgb(139,148,158));
        privacy.setPadding(0,dp(20),0,0); root.addView(privacy);
        setContentView(scroll);
    }

    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent launcher = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<android.content.pm.ResolveInfo> infos = pm.queryIntentActivities(launcher, 0);
        Map<String,String> labels = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (android.content.pm.ResolveInfo r : infos) {
            String pkg = r.activityInfo.packageName;
            if (pkg.equals(getPackageName())) continue;
            labels.put(String.valueOf(r.loadLabel(pm)), pkg);
        }
        for (Map.Entry<String,String> e : labels.entrySet()) {
            CheckBox cb = new CheckBox(this);
            cb.setText(e.getKey() + "\n" + e.getValue()); cb.setTextColor(Color.rgb(240,246,252)); cb.setTextSize(14); cb.setPadding(0,dp(5),0,dp(5));
            cb.setChecked(blocked.contains(e.getValue()));
            cb.setOnCheckedChangeListener((b,v) -> { if (v) blocked.add(e.getValue()); else blocked.remove(e.getValue()); RuleStore.setBlocked(this, blocked); });
            appList.addView(cb);
        }
    }

    private void requestVpnAndStart() {
        RuleStore.setBlocked(this, blocked);
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) startActivityForResult(prepare, VPN_REQUEST); else startFirewall();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST && resultCode == RESULT_OK) startFirewall();
    }

    private void startFirewall() {
        if (!RuleStore.lockdown(this) && blocked.isEmpty()) { Toast.makeText(this, "Select at least one app or enable LOCKDOWN.", Toast.LENGTH_LONG).show(); return; }
        Intent i = new Intent(this, FirewallVpnService.class).setAction(FirewallVpnService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        status.setText(RuleStore.lockdown(this) ? "LOCKDOWN ACTIVE" : "Firewall active — selected apps blocked");
        status.setTextColor(Color.rgb(63,185,80));
    }

    private void stopFirewall() {
        startService(new Intent(this, FirewallVpnService.class).setAction(FirewallVpnService.ACTION_STOP));
        status.setText("Firewall stopped"); status.setTextColor(Color.rgb(248,81,73));
    }

    private void showLogs() {
        File f = new File(getFilesDir(), "blocked_connections.log");
        StringBuilder sb = new StringBuilder();
        if (f.exists()) try (BufferedReader r = new BufferedReader(new FileReader(f))) {
            ArrayDeque<String> q = new ArrayDeque<>(); String line;
            while ((line = r.readLine()) != null) { q.addLast(line); if (q.size() > 150) q.removeFirst(); }
            for (String s : q) sb.append(s).append('\n');
        } catch (Exception ignored) {}
        if (sb.length()==0) sb.append("No blocked connection attempts logged yet.");
        TextView tv = new TextView(this); tv.setText(sb.toString()); tv.setTextColor(Color.WHITE); tv.setTextSize(12); tv.setPadding(dp(12),dp(12),dp(12),dp(12)); tv.setTextIsSelectable(true);
        new android.app.AlertDialog.Builder(this).setTitle("Blocked connections").setView(tv).setPositiveButton("CLOSE",null).show();
    }

    private void requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 9);
    }

    private TextView text(String s, int size, int color) { TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); return v; }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setAllCaps(false); b.setTextSize(13); return b; }
    private Switch makeSwitch(String s, boolean checked) { Switch sw=new Switch(this); sw.setText(s); sw.setTextColor(Color.WHITE); sw.setTextSize(15); sw.setChecked(checked); sw.setPadding(0,dp(10),0,dp(4)); return sw; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
}
