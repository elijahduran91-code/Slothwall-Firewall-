package com.slothwall.firewall;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public final class RuleStore {
    private static final String PREFS = "slothwall_rules";
    private static final String BLOCKED = "blocked_packages";
    private static final String LOCKDOWN = "lockdown";
    private static final String AUTOSTART = "autostart";

    private RuleStore() {}

    public static Set<String> blocked(Context c) {
        return new HashSet<>(c.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getStringSet(BLOCKED, new HashSet<>()));
    }

    public static void setBlocked(Context c, Set<String> packages) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putStringSet(BLOCKED, new HashSet<>(packages)).apply();
    }

    public static boolean lockdown(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(LOCKDOWN, false);
    }

    public static void setLockdown(Context c, boolean value) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(LOCKDOWN, value).apply();
    }

    public static boolean autostart(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(AUTOSTART, false);
    }

    public static void setAutostart(Context c, boolean value) {
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(AUTOSTART, value).apply();
    }
}
