package com.slothwall.firewall;

import android.content.Context;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public final class PacketLogger {
    private PacketLogger() {}

    public static synchronized void log(Context context, byte[] p, int len) {
        if (len < 20) return;
        int version = (p[0] >> 4) & 0xF;
        String entry = version == 4 ? parseV4(p, len) : (version == 6 ? parseV6(p, len) : "Unknown packet");
        try {
            File file = new File(context.getFilesDir(), "blocked_connections.log");
            if (file.length() > 1024 * 1024) file.delete();
            try (FileWriter w = new FileWriter(file, true)) {
                String ts = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
                w.write(ts + "  " + entry + "\n");
            }
        } catch (Exception ignored) {}
    }

    private static String parseV4(byte[] p, int len) {
        int ihl = (p[0] & 0x0F) * 4;
        if (len < ihl || ihl < 20) return "Malformed IPv4";
        int proto = p[9] & 0xFF;
        String dst = (p[16] & 255) + "." + (p[17] & 255) + "." + (p[18] & 255) + "." + (p[19] & 255);
        int port = 0;
        if ((proto == 6 || proto == 17) && len >= ihl + 4) port = ((p[ihl + 2] & 255) << 8) | (p[ihl + 3] & 255);
        return "BLOCK IPv4 " + protocol(proto) + " -> " + dst + (port > 0 ? ":" + port : "");
    }

    private static String parseV6(byte[] p, int len) {
        if (len < 40) return "Malformed IPv6";
        int proto = p[6] & 0xFF;
        StringBuilder dst = new StringBuilder();
        for (int i = 24; i < 40; i += 2) {
            if (i > 24) dst.append(':');
            dst.append(String.format(Locale.US, "%02x%02x", p[i] & 255, p[i + 1] & 255));
        }
        int port = 0;
        if ((proto == 6 || proto == 17) && len >= 44) port = ((p[42] & 255) << 8) | (p[43] & 255);
        return "BLOCK IPv6 " + protocol(proto) + " -> " + dst + (port > 0 ? ":" + port : "");
    }

    private static String protocol(int p) {
        if (p == 6) return "TCP";
        if (p == 17) return "UDP";
        if (p == 1 || p == 58) return "ICMP";
        return "PROTO-" + p;
    }
}
