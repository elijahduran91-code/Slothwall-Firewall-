package com.slothwall.firewall;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || !RuleStore.autostart(context)) return;
        if (VpnService.prepare(context) != null) return; // user has not granted VPN consent yet
        Intent s = new Intent(context, FirewallVpnService.class).setAction(FirewallVpnService.ACTION_START);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(s); else context.startService(s);
    }
}
