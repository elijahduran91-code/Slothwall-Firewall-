package com.slothwall.firewall;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.util.Set;

public class FirewallVpnService extends VpnService {
    public static final String ACTION_START = "com.slothwall.firewall.START";
    public static final String ACTION_STOP = "com.slothwall.firewall.STOP";
    private static final String CHANNEL = "slothwall_firewall";
    private ParcelFileDescriptor tun;
    private Thread reader;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopFirewall();
            return START_NOT_STICKY;
        }
        startForeground(7, notification());
        startFirewall();
        return START_STICKY;
    }

    private synchronized void startFirewall() {
        stopTunnelOnly();
        Builder b = new Builder()
                .setSession("Slothwall Firewall")
                .setMtu(1500)
                .addAddress("10.77.0.1", 32)
                .addAddress("fd77::1", 128)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .setBlocking(true);

        boolean lockdown = RuleStore.lockdown(this);
        Set<String> blocked = RuleStore.blocked(this);
        if (!lockdown) {
            if (blocked.isEmpty()) {
                stopSelf();
                return;
            }
            for (String pkg : blocked) {
                if (pkg.equals(getPackageName())) continue;
                try { b.addAllowedApplication(pkg); }
                catch (PackageManager.NameNotFoundException ignored) {}
            }
        }

        try {
            tun = b.establish();
            if (tun == null) { stopSelf(); return; }
            reader = new Thread(this::dropLoop, "SlothwallDropLoop");
            reader.start();
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void dropLoop() {
        byte[] buf = new byte[32767];
        try (FileInputStream in = new FileInputStream(tun.getFileDescriptor())) {
            while (!Thread.currentThread().isInterrupted()) {
                int n = in.read(buf);
                if (n > 0) PacketLogger.log(this, buf, n); // deliberately do not forward
            }
        } catch (Exception ignored) {}
    }

    private Notification notification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Firewall status", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Shows when Slothwall Firewall is active");
            nm.createNotificationChannel(c);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("Slothwall Firewall is active")
                .setContentText(RuleStore.lockdown(this) ? "LOCKDOWN: all app traffic is blocked" : "Selected apps are blocked")
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setOngoing(true)
                .setContentIntent(pi)
                .build();
    }

    private synchronized void stopTunnelOnly() {
        if (reader != null) { reader.interrupt(); reader = null; }
        if (tun != null) { try { tun.close(); } catch (Exception ignored) {} tun = null; }
    }

    private void stopFirewall() {
        stopTunnelOnly();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override public void onDestroy() { stopTunnelOnly(); super.onDestroy(); }
    @Override public void onRevoke() { stopFirewall(); super.onRevoke(); }
}
