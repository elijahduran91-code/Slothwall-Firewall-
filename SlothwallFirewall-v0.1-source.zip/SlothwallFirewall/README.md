# Slothwall Firewall

Slothwall is a privacy-first, no-root Android firewall prototype using Android `VpnService`.

## v0.1 features
- Block internet access for selected launcher apps.
- LOCKDOWN mode blocks all traffic routed by the VPN.
- Local blocked-packet log (destination IP, protocol and port when available).
- Optional restart after boot once Android VPN consent has already been granted.
- No HTTPS interception, no custom CA certificate, no telemetry, no cloud logging.

## How selective blocking works
When selective mode is active, Android routes only user-selected apps into the Slothwall VPN interface. Slothwall deliberately does not forward those packets, so those apps cannot reach the network. Other apps bypass Slothwall normally.

## Important v0.1 limitations
- The connection log records blocked attempts only; it is not yet a transparent monitor of allowed traffic.
- Domain/ad/tracker filtering is not implemented yet. That requires a DNS proxy / packet forwarding engine rather than simply dropping selected apps.
- Android generally allows only one active VPN service per user/profile.
- Some system components do not appear in the launcher-app list.

## Build in GitHub
1. Create a repository and upload this project.
2. Push to `main`, or open **Actions → Build Slothwall APK → Run workflow**.
3. Open the completed workflow run and download the `Slothwall-Firewall-APK` artifact.
4. Extract it and install `app-debug.apk` on your Android device. Android may ask you to allow installs from your browser/files app.

## Security design
Slothwall does not decrypt TLS/HTTPS, does not install a CA certificate, and does not transmit logs off-device.
